% Define parameters
T = 30000; % Line tension (N)
l = 125;   % Line length (m)
n = 1;     % Harmonic number
m = 2.4;   % Linear mass of wire (kg/m)
v = 9;     % Wind speed (m/s)

% Define power line data
powerlinedata = [      
    0         0.84         0
    pi/6      1.95      -1.67
    pi/3      3.35      -0.84
    pi/2      3.38       0.56
    2*pi/3    2.51       1.39
    5*pi/6    1.39      -0.69
    pi        1.12         0
    7*pi/6    1.53       0.84
    4*pi/3    2.23      -1.12
    3*pi/2    3.77      -0.14
    5*pi/3    3.91       0.70
    11*pi/6   2.37       2.37
    2*pi      0.84         0
];

% Create spline objects for D and L functions
Dspline = spline(powerlinedata(:,1), powerlinedata(:,2)); % Construct spline object for drag
Lspline = spline(powerlinedata(:,1), powerlinedata(:,3)); % Construct spline object for lift

% Define functions to evaluate D and L at any angle
Dfun = @(alpha) ppval(Dspline, mod(alpha, 2*pi)); % Ensure angle is within [0, 2*pi]
Lfun = @(alpha) ppval(Lspline, mod(alpha, 2*pi)); % Ensure angle is within [0, 2*pi]



% Define the differential equation system
dydt = @(t, y) [
    y(2);
    (-T/m)*(n * pi / l)^2 * y(1) - (v * -Lfun(atan2(y(2), v)) - Dfun(atan2(y(2), v)))/(m*(y(2)^2+v^2))
];

% Define time span
tspan = [0 60];

% Define initial conditions
y0 = [0.1; 0]; % Initial position (m) and velocity (m/s)

% Solve the differential equations
[t, y] = ode45(dydt, tspan, y0);

% Plot the vertical position of the power line
plot(t, y(:, 1));
xlabel('Time (s)');
ylabel('Vertical Position (m)');
title('Vertical Position of Galloping Power Line');


% %(a) Curve Fitting Toolbox, (b) Optimization Toolbox, (c) Signal Processing Toolbox, (d) Symbolic Math Toolbox.
% 
% % Curve Fitting Toolbox
% cf_toolbox_url = matlab.addons.installer.getDownloadURL('Curve_Fitting_Toolbox');
% 
% % Optimization Toolbox
% opt_toolbox_url = matlab.addons.installer.getDownloadURL('Optimization_Toolbox');
% 
% % Signal Processing Toolbox
% sp_toolbox_url = matlab.addons.installer.getDownloadURL('Signal_Processing_Toolbox');
% 
% % Symbolic Math Toolbox
% sym_toolbox_url = matlab.addons.installer.getDownloadURL('Symbolic_Math_Toolbox');
