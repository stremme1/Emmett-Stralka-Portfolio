#
# hw9pr1.py - Game of Life lab (Conway)
#
# Name:
#

import random

def createOneRow(width):
    """Returns one row of zeros of width "width"...  
       You might use this in your createBoard(width, height) function."""
    row = []
    for col in range(width):
        row += [0]
    return row



























#
# +++ Helper functions for when Life has been completed! +++
#

"""
These functions allow for "terminal-graphics animation."

Once next_life_generation is complete, run:

   lifedemo()

You may need to adjust your terminal's shape or size to 
    create a smooth animation.
"""

def printBoard_with_d(A, d = None):
    """This function prints the 2d list-of-lists A
       using the dictionary d 
    """
    if (d == None) or (0 not in d) or (1 not in d): # Can we use d?
        for row in A:
            for col in row:
                print(col, end = '')                # Use raw contents
            print()
    else:
        for row in A:
            for col in row:
                print(d[col], end = '')             # Look each value up
            print()

def placeObject(row, col, A, offsets):
    """Creates an arbitrary object whose upper-left corner
       is at row row and column col.  1's are placed at the
       coordinates given by offsets, which is a list of
       coordinate pairs."""
    H = len(A)
    W = len(A[0])
    for row_offset, col_offset in offsets:
        r = row + row_offset
        c = col + col_offset
        if 0 < r < H-1 and 0 < c < W-1: # stay in bounds!
            A[r][c] = 1
    # No need to return A; A is changed in place!

def placeGlider(row, col, A):
    """Creates a glider with a bounding box
       whose upper-left corner is at row row and column col
    """
    OFFSETS = [[+0,+1], [+1,+2], [+2,+0], [+2,+1], [+2,+2]]
    placeObject(row, col, A, OFFSETS)
    # No need to return A; A is changed in place!

def placeAirDancer(row, col, A):
    """Creates an up-down air dancer (also known as a
       stoplight) with its upper-left corner at row row
       and column col
    """
    OFFSETS = [[+0,+0], [+1,+0], [+2,+0]]
    placeObject(row, col, A, OFFSETS)
    # No need to return A; A is changed in place!

import time

def lifedemo():
    """ASCII demo! 
    """
    W = 42                    # Alter to suit!
    H = 21                    # Alter to suit!
    
    A = createBoard(W, H)     # Empty grid
    placeGlider(2, 2, A)
    placeAirDancer(2, 20, A)
    placeAirDancer(3, 36, A)

    # A = randomCells(W, H)   # Random grid
    
    # dictionaries to indicate what to print
    # d = {0: 0,    1: 1}
    # d = {0: 0,    1: " "}
    d = {0: ".",  1: "X"}
    # d = {0: " ",  1: "0"}
    # d = {0: " ",  1: "#"}
    # d = {0: "▯", 1: "▮"}
    # d = {0: " ",  1: "🙂"} 


    while True:
        print("\n")

        
        printBoard_with_d(A, d)
        print("\n")
        A = next_life_generation(A)
        time.sleep(0.42)


# The terminal colors don't seem as successful
# d = { 0: "\033[6;36;47m0\033[0m", 1: "\033[6;37;40m1\033[0m" }
# www.cs.hmc.edu/twiki/bin/view/CS5/TerminalColorsInPython


#
# +++ End of helper functions +++
#
